function openNav() {
    document.getElementById("mySidenav").style.width = "250px";
    document.getElementById("main").style.marginLeft = "250px";
  }


  function closeNav() {
    document.getElementById("mySidenav").style.width = "0";
    document.getElementById("main").style.marginLeft = "0";
  } 

  function slidedown(){
      document.getElementById().style.display = "block";
  }
  function slidedown(){
    document.getElementById().style.display = "none";
    }